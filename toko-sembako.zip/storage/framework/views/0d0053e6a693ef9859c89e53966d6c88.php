

<?php $__env->startSection('title', 'Laporan toko'); ?>

<?php $__env->startSection('content'); ?>
<main class="admin-page">
    <div class="admin-page-head">
        <div>
            <p class="eyebrow">RINGKASAN OPERASIONAL</p>
            <h1>Laporan toko</h1>
            <p>Omzet, laba kotor dan stok yang perlu diperhatikan.</p>
        </div>

<nav class="admin-actions" aria-label="Menu laporan">
            <a class="admin-button is-secondary"
                href="<?php echo e(route('reports.stock')); ?>">
                Log & stok
            </a>
        </nav>
    </div>

    <form class="report-filter" method="get"
        action="<?php echo e(route('reports.index')); ?>">
        <label for="report-start">Dari tanggal</label>
        <input id="report-start" name="start_date" type="date"
            value="<?php echo e($start ?? $date); ?>">

        <label for="report-end">Sampai tanggal</label>
        <input id="report-end" name="end_date" type="date"
            value="<?php echo e($end ?? $date); ?>">

        <button class="admin-button" type="submit">
            Tampilkan
        </button>
    </form>

    <section class="report-stats" aria-label="Ringkasan penjualan">
        <article class="report-stat">
            <span>Omzet</span>
            <strong>
                Rp<?php echo e(number_format((float) $dailyTotal, 0, ',', '.')); ?>

            </strong>
            <small>
                <?php echo e(\Illuminate\Support\Carbon::parse($start)->translatedFormat('d F Y')); ?>

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($start !== $end): ?>
                    – <?php echo e(\Illuminate\Support\Carbon::parse($end)->translatedFormat('d F Y')); ?>

                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </small>
        </article>

        <article class="report-stat">
            <span>Laba kotor</span>
            <strong>
                Rp<?php echo e(number_format((float) $dailyProfit, 0, ',', '.')); ?>

            </strong>
            <small>
                Harga jual dikurangi modal produk; belum termasuk biaya operasional
            </small>
        </article>

        <article class="report-stat">
            <span>Transaksi selesai</span>
            <strong><?php echo e(number_format($dailyCount, 0, ',', '.')); ?></strong>
            <small>Kasir dan pesanan online</small>
        </article>

        <article class="report-stat">
            <span>Produk terlaris</span>
            <strong><?php echo e($bestSeller?->product_name ?? 'Belum ada'); ?></strong>
            <small>
                <?php echo e($bestSeller
                    ? rtrim(rtrim((string) $bestSeller->sold_quantity, '0'), '.').' unit'
                    : 'Tidak ada penjualan pada tanggal ini'); ?>

            </small>
        </article>
    </section>

    <section class="admin-card">
        <div class="admin-card-head">
            <div>
                <p class="eyebrow">PEMBAYARAN</p>
                <h2>Metode pembayaran</h2>
            </div>
        </div>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(($paymentMethods ?? collect())->isEmpty()): ?>
            <p class="admin-empty">Belum ada transaksi pada periode ini.</p>
        <?php else: ?>
            <div class="stock-log-list">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $paymentMethods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paymentMethod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <article class="stock-log-row">
                        <div>
                            <strong>
                                <?php echo e(match ($paymentMethod->payment_method) {
                                    'cash' => 'Tunai',
                                    'qris' => 'QRIS',
                                    'bank_transfer' => 'Transfer bank',
                                    'cash_on_pickup' => 'Bayar saat diambil',
                                    default => ucfirst(str_replace('_', ' ', (string) $paymentMethod->payment_method)),
                                }); ?>

                            </strong>
                            <small><?php echo e(number_format((int) $paymentMethod->transaction_count, 0, ',', '.')); ?> transaksi</small>
                        </div>

                        <strong>
                            Rp<?php echo e(number_format((float) $paymentMethod->total_amount, 0, ',', '.')); ?>

                        </strong>
                    </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </section>

    <section class="admin-card">
        <div class="admin-card-head">
            <div>
                <p class="eyebrow">PERSEDIAAN</p>
                <h2>Peringatan stok rendah</h2>
            </div>

            <a href="<?php echo e(route('reports.stock')); ?>">
                Lihat seluruh riwayat →
            </a>
        </div>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $lowStockProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="stock-warning-row">
                <span>
                    <strong><?php echo e($product->name); ?></strong>
                    <small>
                        <?php echo e($product->category?->name ?? 'Lainnya'); ?>

                    </small>
                </span>

                <strong class="<?php echo e((float) $product->stock <= 0 ? 'is-danger' : 'is-warning'); ?>">
                    <?php echo e(rtrim(rtrim((string) $product->stock, '0'), '.')); ?>

                    <?php echo e($product->unit); ?>

                </strong>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="admin-empty">
                Semua produk memiliki stok yang cukup.
            </p>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </section>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.storefront', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\toko-sembako\resources\views/admin/reports.blade.php ENDPATH**/ ?>