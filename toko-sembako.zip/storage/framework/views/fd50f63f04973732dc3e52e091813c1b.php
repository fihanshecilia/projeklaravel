

<?php $__env->startSection('title', 'Riwayat stok'); ?>

<?php $__env->startSection('content'); ?>
<main class="admin-page">
    <div class="admin-page-head">
        <div>
            <p class="eyebrow">PERSEDIAAN TOKO</p>
            <h1>Log & peringatan stok</h1>
            <p>
                Perubahan stok masuk, reservasi, penjualan dan pembatalan.
            </p>
        </div>

        <nav class="admin-actions" aria-label="Menu laporan">
            <a class="admin-button is-secondary"
                href="<?php echo e(route('reports.index')); ?>">
                ← Laporan toko
            </a>

            <a class="admin-button" href="<?php echo e(url('/admin/products')); ?>">
                Kelola produk
            </a>
        </nav>
    </div>

    <section class="admin-card">
        <div class="admin-card-head">
            <div>
                <p class="eyebrow">PERLU DIPERIKSA</p>
                <h2>Stok mencapai batas minimum</h2>
            </div>
        </div>

        <div class="stock-warning-grid">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $lowStockProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <article class="stock-warning-card">
                    <span><?php echo e($product->category?->name ?? 'Lainnya'); ?></span>
                    <strong><?php echo e($product->name); ?></strong>
                    <small>
                        <?php echo e(rtrim(rtrim((string) $product->stock, '0'), '.')); ?>

                        <?php echo e($product->unit); ?> tersedia
                    </small>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="admin-empty">
                    Tidak ada produk yang mencapai batas stok minimum.
                </p>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </section>

    <section class="admin-card">
        <div class="admin-card-head">
            <div>
                <p class="eyebrow">HISTORI</p>
                <h2>Aktivitas stok</h2>
            </div>
        </div>

        <div class="stock-log-list">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $stockLogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <article class="stock-log-row">
                    <span class="stock-log-mark <?php echo e(in_array(
                            $log->type,
                            ['incoming', 'initial', 'cancellation'],
                            true
                        ) ? 'is-in' : 'is-out'); ?>">
                        <?php echo e(in_array(
                            $log->type,
                            ['incoming', 'initial', 'cancellation'],
                            true
                        ) ? '+' : '−'); ?>

                    </span>

                    <div>
                        <strong>
                            <?php echo e($log->product?->name ?? 'Produk dihapus'); ?>

                        </strong>
                        <small>
                            <?php echo e($log->note ?: ucfirst($log->type)); ?>

                            · <?php echo e($log->user?->name ?? 'Sistem'); ?>

                        </small>
                    </div>

                    <strong>
                        <?php echo e(rtrim(
                            rtrim((string) abs((float) $log->quantity_change), '0'),
                            '.'
                        )); ?>

                        <?php echo e($log->product?->unit ?? 'unit'); ?>

                    </strong>

                    <time datetime="<?php echo e($log->created_at->toIso8601String()); ?>">
                        <?php echo e($log->created_at->format('d M Y, H:i')); ?>

                    </time>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="admin-empty">Belum ada histori stok.</p>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>

        <?php echo e($stockLogs->links()); ?>

    </section>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.storefront', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\toko-sembako\resources\views/admin/stock.blade.php ENDPATH**/ ?>