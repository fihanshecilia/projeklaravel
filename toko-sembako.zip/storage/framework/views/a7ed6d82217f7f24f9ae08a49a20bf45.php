<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>
        <?php echo $__env->yieldContent('title', 'TOKO SILATURIZKY'); ?> | Kasir & Manajemen Toko
    </title>

    <meta name="description"
        content="Sistem Kasir dan Manajemen Toko Sembako TOKO SILATURIZKY.">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Fraunces:opsz,wght@9..144,600;9..144,700&display=swap"
        rel="stylesheet">

    <script>
        (function () {
            try {
                var theme = localStorage.getItem('silaturizky-theme') || 'light';
                document.documentElement.setAttribute('data-theme', theme);
            } catch (e) {}
        })();
    </script>

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>

<body>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if (! (request()->is('kasir*', 'admin*', 'profil', 'login*', 'masuk*'))): ?>
    <header class="site-header">
        <a class="brand" href="<?php echo e(auth()->check() ? (auth()->user()->isStoreAdmin() ? url('/admin') : route('pos.index')) : route('employee.login')); ?>"
            aria-label="TOKO SILATURIZKY, beranda">
            <span class="brand-mark" aria-hidden="true">S</span>

            <span class="brand-copy">
                <strong>TOKO</strong>
                <b>SILATURIZKY</b>
                <small>SEMBAKO PILIHAN KELUARGA</small>
            </span>
        </a>

        <nav class="main-nav" aria-label="Navigasi utama">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->guard()->check()): ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->user()->can('use-pos')): ?>
                    <a href="<?php echo e(route('pos.index')); ?>">Kasir POS</a>
                    <a href="<?php echo e(route('pos.history')); ?>">Histori</a>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->user()->can('manage-store')): ?>
                    <a href="<?php echo e(route('reports.index')); ?>">Laporan</a>
                    <a href="<?php echo e(route('reports.stock')); ?>">Stok</a>
                    <a href="<?php echo e(url('/admin')); ?>">Panel Admin</a>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </nav>

        <div style="display: flex; align-items: center; gap: 0.75rem;">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->guard()->check()): ?>
                <span style="font-size: 0.875rem; color: #475569; font-weight: 500;">
                    <?php echo e(auth()->user()->name); ?>

                </span>
                <form method="post" action="<?php echo e(route('employee.logout')); ?>" style="display: inline; margin: 0;">
                    <?php echo csrf_field(); ?>
                    <button class="header-cart" type="submit" style="cursor: pointer; padding: 0.45rem 0.9rem; border-radius: 9999px;">
                        Keluar
                    </button>
                </form>
            <?php else: ?>
                <a class="header-account" href="<?php echo e(route('employee.login')); ?>">
                    Masuk
                </a>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </header>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <?php echo $__env->yieldContent('content'); ?>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if (! (request()->is('kasir*', 'admin*', 'profil', 'login*', 'masuk*'))): ?>
    <footer class="site-footer" id="tentang">
        <div class="footer-brand">
            <span class="brand-mark" aria-hidden="true">S</span>

            <div>
                <strong>TOKO SILATURIZKY</strong>
                <small>Sistem Kasir & Operasional Toko.</small>
            </div>
        </div>

        <p>
            Manajemen sembako, kasir cerdas, pencatatan stok, dan laporan berkala.
        </p>

        <span class="footer-note">
            © <?php echo e(date('Y')); ?> TOKO SILATURIZKY
        </span>
    </footer>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</body>
</html>
<?php /**PATH D:\laragon\www\toko-sembako\resources\views/layouts/storefront.blade.php ENDPATH**/ ?>