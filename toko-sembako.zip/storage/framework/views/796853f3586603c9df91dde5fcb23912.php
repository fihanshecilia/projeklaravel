<?php $__env->startSection('title', 'Histori Transaksi'); ?>

<?php $__env->startSection('content'); ?>
<main class="admin-page order-history-page">
    <div class="admin-page-head">
        <div>
            <p class="eyebrow">RIWAYAT TRANSAKSI</p>
            <h1>Histori Transaksi</h1>
            <p>
                Rekam jejak seluruh transaksi kasir POS toko.
            </p>
        </div>

        <nav class="admin-actions" aria-label="Menu histori">
            <a class="admin-button is-secondary"
                href="<?php echo e(route('pos.index')); ?>">
                ← Kasir POS
            </a>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->user()->can('manage-store')): ?>
                <a class="admin-button" href="<?php echo e(route('reports.index')); ?>">
                    Dashboard Admin
                </a>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </nav>
    </div>

    <section class="admin-card" style="margin-bottom: 1rem;">
        <form method="get" action="<?php echo e(route('pos.history')); ?>" class="report-filter" style="display: flex; gap: .75rem; flex-wrap: wrap; align-items: end;">
            <div>
                <label for="history-search">Nomor transaksi</label>
                <input id="history-search" name="search" type="search" value="<?php echo e($search ?? ''); ?>" placeholder="TRX-...">
            </div>
            <div>
                <label for="history-date">Tanggal</label>
                <input id="history-date" name="date" type="date" value="<?php echo e($date ?? ''); ?>">
            </div>
            <div>
                <label for="history-from">Dari</label>
                <input id="history-from" name="from" type="date" value="<?php echo e($from ?? ''); ?>">
            </div>
            <div>
                <label for="history-to">Sampai</label>
                <input id="history-to" name="to" type="date" value="<?php echo e($to ?? ''); ?>">
            </div>
            <button class="admin-button" type="submit">Cari</button>
            <a class="admin-button is-secondary" href="<?php echo e(route('pos.history')); ?>">Reset</a>
        </form>
    </section>

    <section class="admin-card">
        <div class="admin-card-head">
            <div>
                <p class="eyebrow">SEMUA TRANSAKSI</p>
                <h2>Riwayat penjualan</h2>
            </div>
        </div>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <article class="history-order">
                <header>
                    <div>
                        <strong><?php echo e($order->transaction_number); ?></strong>
                        <small>
                            <?php echo e($order->created_at->format('d M Y, H:i')); ?>

                        </small>
                    </div>

                    <span class="history-status status-<?php echo e($order->status); ?>">
                        <?php echo e(match ($order->status) {
                            'pending', 'pending_pickup' => 'Menunggu konfirmasi',
                            'processing' => 'Diproses',
                            'delivering' => 'Diantar',
                            'completed' => 'Selesai',
                            'cancelled' => 'Dibatalkan',
                            default => ucfirst($order->status),
                        }); ?>

                    </span>
                </header>

                <div class="history-items">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $order->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div>
                            <span>
                                <?php echo e($detail->product_name); ?>

                                ×
                                <?php echo e(rtrim(rtrim((string) $detail->quantity, '0'), '.')); ?>

                                <?php echo e($detail->unit); ?>

                            </span>

                            <strong>
                                Rp<?php echo e(number_format((float) $detail->subtotal, 0, ',', '.')); ?>

                            </strong>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>

                <footer>
                    <strong>
                        Total Rp<?php echo e(number_format((float) $order->total, 0, ',', '.')); ?>

                    </strong>

                    <span class="history-channel">
                        Pembayaran:
                        <?php echo e($order->payment_status === 'paid'
                            ? 'Terkonfirmasi'
                            : ($order->payment_status === 'refund_required'
                                ? 'Perlu pengembalian dana'
                                : ($order->payment_status === 'refunded'
                                    ? 'Dana dikembalikan'
                                    : ($order->payment_method === 'cash_on_pickup'
                                        ? 'Bayar saat diterima'
                                        : 'Menunggu verifikasi')))); ?>

                    </span>

                    <div>
                        <span class="history-channel">
                            Kasir
                        </span>

                        <a class="history-track"
                            href="<?php echo e(route('pos.receipts.show', $order->transaction_number)); ?>">
                            Struk
                        </a>
                    </div>
                </footer>
            </article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="admin-empty">Belum ada riwayat transaksi.</p>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <?php echo e($orders->links()); ?>

    </section>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.storefront', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\toko-sembako\resources\views/pos/history.blade.php ENDPATH**/ ?>