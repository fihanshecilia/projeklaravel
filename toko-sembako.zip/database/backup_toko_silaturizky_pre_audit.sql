-- MySQL dump 10.13  Distrib 8.4.3, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: toko_silaturizky
-- ------------------------------------------------------
-- Server version	8.4.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
INSERT INTO `cache` VALUES ('toko-silaturizky-cache-5c785c036466adea360111aa28563bfd556b5fba','i:1;',1792997404),('toko-silaturizky-cache-5c785c036466adea360111aa28563bfd556b5fba:timer','i:1792997404;',1792997404);
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_locks_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `categories_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'2026-10-17 23:06:40','2026-10-17 23:06:40','Beras',NULL,1),(2,'2026-10-17 23:06:41','2026-10-25 06:14:51','Minyak Goreng',NULL,0),(3,'2026-10-17 23:06:41','2026-10-17 23:06:41','Telur',NULL,1),(4,'2026-10-17 23:06:41','2026-10-17 23:06:41','Gula',NULL,1),(5,'2026-10-17 23:06:41','2026-10-17 23:06:41','Gas LPG',NULL,1),(8,'2026-10-24 19:59:12','2026-10-24 19:59:12','Indomie','mie',1),(9,'2026-10-24 20:32:12','2026-10-24 20:32:12','Terigu','TG',1),(10,'2026-10-24 20:39:42','2026-10-24 20:39:42','Aci','AC',1);
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'0001_01_01_000000_create_users_table',1),(2,'0001_01_01_000001_create_cache_table',1),(3,'0001_01_01_000002_create_jobs_table',1),(4,'2026_09_29_020255_create_categories_table',1),(5,'2026_09_29_020308_create_products_table',1),(6,'2026_09_29_020316_create_sales_table',1),(7,'2026_09_29_020324_create_sale_details_table',1),(8,'2026_10_04_000000_upgrade_toko_inventory_schema',1),(9,'2026_10_04_000001_add_storefront_order_details',1),(10,'2026_10_05_000000_add_customer_and_pickup_fields',1),(11,'2026_10_18_000000_add_storefront_operations_and_database_routines',1),(12,'2026_10_18_000001_add_unique_customer_phone',2),(13,'2026_10_18_000002_rename_order_item_inventory_trigger',3),(14,'2026_10_18_000003_add_canonical_auth_fields_to_users',4),(15,'2026_10_18_000004_add_soft_deletes_to_products',5),(16,'2026_10_19_000000_complete_inventory_audit_and_daily_report',6),(17,'2026_10_19_000001_qualify_daily_report_profit_columns',7),(18,'2026_10_19_000002_remove_legacy_user_fields',8),(19,'2026_10_22_060209_add_payment_tracking_and_completed_at',8),(20,'2026_10_24_234000_remove_carts_table_and_update_database_routines',9),(21,'2026_10_25_000000_add_is_active_to_users',9);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `order_items`
--

DROP TABLE IF EXISTS `order_items`;
/*!50001 DROP VIEW IF EXISTS `order_items`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `order_items` AS SELECT 
 1 AS `id`,
 1 AS `created_at`,
 1 AS `updated_at`,
 1 AS `transaction_id`,
 1 AS `product_id`,
 1 AS `product_name`,
 1 AS `unit`,
 1 AS `quantity`,
 1 AS `unit_price`,
 1 AS `purchase_price`,
 1 AS `subtotal`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!50001 DROP VIEW IF EXISTS `orders`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `orders` AS SELECT 
 1 AS `id`,
 1 AS `created_at`,
 1 AS `updated_at`,
 1 AS `user_id`,
 1 AS `handled_by`,
 1 AS `transaction_number`,
 1 AS `subtotal`,
 1 AS `total`,
 1 AS `total_cost`,
 1 AS `amount_paid`,
 1 AS `change_amount`,
 1 AS `payment_method`,
 1 AS `payment_status`,
 1 AS `status`,
 1 AS `completed_at`,
 1 AS `notes`,
 1 AS `customer_name`,
 1 AS `customer_phone`,
 1 AS `shipping_address`,
 1 AS `pickup_note`,
 1 AS `sales_channel`,
 1 AS `delivery_type`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `category_id` bigint unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sku` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `unit` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pcs',
  `purchase_price` decimal(15,2) NOT NULL DEFAULT '0.00',
  `selling_price` decimal(15,2) NOT NULL DEFAULT '0.00',
  `stock` decimal(12,3) NOT NULL DEFAULT '0.000',
  `min_stock` decimal(12,3) NOT NULL DEFAULT '0.000',
  `image_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `products_sku_unique` (`sku`),
  KEY `products_category_id_foreign` (`category_id`),
  CONSTRAINT `products_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,'2026-10-17 23:06:40','2026-10-24 19:46:40',1,'SPHP Bulog 5kg','BR-005','kg',11500.00,12000.00,75.000,10.000,'products/01M5RENJ9860KYMSCK47WFS6TR.jpg',1,NULL),(2,'2026-10-17 23:06:41','2026-10-24 20:08:54',2,'MinyakKita 1L','MG-001','pcs',15500.00,18000.00,40.000,10.000,NULL,1,'2026-10-24 20:08:54'),(3,'2026-10-17 23:06:41','2026-10-24 17:29:19',3,'Telor Ayam 1kg','TL-001','kg',26000.00,30000.00,25.000,10.000,'products/01M594PBFF0WF8V0YNR34HT4HQ.jpg',1,'2026-10-24 17:29:19'),(4,'2026-10-17 23:06:41','2026-10-24 21:30:35',4,'Gula Pasir Putih curah','GL-001','kg',14500.00,16000.00,26.000,10.000,'products/01M5RGFARQ9NAAS5YFJGYKQX88.jpg',1,NULL),(5,'2026-10-17 23:06:41','2026-10-24 20:10:30',5,'Gas LPG 3kg','GS-003','tabung',18000.00,22000.00,59.000,10.000,'products/01M5RGKKCEKJ6P2KAB5XVMVD9Q.jpg',1,NULL),(7,'2026-10-24 19:45:06','2026-10-24 19:45:06',1,'Medium IR64/C4','BR-002','kg',13000.00,15000.00,20.000,5.000,'products/01M5RF537PC5A2K4BHZK1C459W.jpg',1,NULL),(8,'2026-10-24 19:49:32','2026-10-24 19:49:32',1,'Premium IR64/Pandan Wangi ','BR-003','kg',14000.00,16000.00,30.000,5.000,'products/01M5RFD77GAYP65XHRJDXXBD7N.jpg',1,NULL),(9,'2026-10-24 19:51:42','2026-10-25 06:57:01',1,'Beras Ketan Putih','BR-004','kg',18000.00,20000.00,16.000,5.000,'products/01M5RFH6FTNEA3BDNKJ8NQZJGW.jpg',1,NULL),(10,'2026-10-24 20:02:28','2026-10-24 20:03:53',8,'Indomie goreng','MI-001','pcs',2000.00,3000.00,80.000,10.000,'products/01M5RG4X86AR566BHQPCZ8G41S.webp',1,NULL),(11,'2026-10-24 20:12:25','2026-10-24 20:12:25',8,'Indomie Ayam Bawang','MI-002','pcs',2000.00,3000.00,80.000,10.000,'products/01M5RGQ42DAQSZZZE2RN842MG2.jpg',1,NULL),(12,'2026-10-24 20:14:16','2026-10-24 20:14:16',8,'Indomie Soto','MI-003','pcs',2000.00,3000.00,80.000,10.000,'products/01M5RGTGJ7XD94WV9YDY1J5F1R.jpg',1,NULL),(13,'2026-10-24 20:17:41','2026-10-24 21:31:20',8,'Indomie Goreng Jumbo ','MI-004','pcs',3000.00,5000.00,79.000,10.000,'products/01M5RH0R8ETBS3VVAGFV0G55D4.jpg',1,NULL),(14,'2026-10-24 20:21:05','2026-10-24 20:21:05',8,'Indomie Goreng Rendang','MI-005','pcs',3200.00,4000.00,80.000,10.000,'products/01M5RH704T3QV0NXJAPZ79EBN9.jpg',1,NULL),(15,'2026-10-24 20:23:18','2026-10-24 21:31:20',8,'Indomie Goreng Cabe Ijo','MI-006','pcs',3200.00,4000.00,79.000,10.000,'products/01M5RHB1WH6K7MZGA9H7EC2YPJ.jpg',1,NULL),(16,'2026-10-24 20:26:10','2026-10-25 14:02:59',4,'Gulaku Kuning 1kg','GL-002','kg',17000.00,19000.00,99.000,10.000,'products/01M5RHG9KXZJKD8TGTC80VGMBC.jpg',1,NULL),(17,'2026-10-24 20:31:13','2026-10-24 20:31:13',4,'Gula Merah Batok ','GL-003','kg',18000.00,22000.00,100.000,10.000,'products/01M5RHSHCM041K3B02EVKGRDKZ.jpg',1,NULL),(18,'2026-10-24 20:34:20','2026-10-24 20:34:20',9,'Segitiga Biru 1kg','TG-001','kg',11500.00,13000.00,100.000,50.000,'products/01M5RHZ81YSV0JM4RP1KQZ32G4.jpg',1,NULL),(19,'2026-10-24 20:35:47','2026-10-24 20:35:47',9,'Terigu Cakra Kembar 1kg','TG-002','kg',12500.00,14500.00,100.000,30.000,'products/01M5RJ1XE8XYZEQCXNDK1VZR2P.jpg',1,NULL),(20,'2026-10-24 20:37:32','2026-10-24 20:37:32',9,'Curah 1kg','TG-003','kg',9500.00,11000.00,100.000,20.000,'products/01M5RJ53DEH707YB581F72CPRF.jpg',1,NULL),(21,'2026-10-24 20:43:18','2026-10-24 20:43:18',10,'Rose Brand 1kg','AC-001','kg',6500.00,8000.00,90.000,10.000,'products/01M5RJFN84DJTAZ3C06418CE5V.jpg',1,NULL),(22,'2026-10-24 20:44:58','2026-10-25 14:02:59',10,'Aci Curah 1kg','AC-002','kg',9000.00,11000.00,99.000,10.000,'products/01M5RJJPYCW69B7BA9N02XZXHX.jpg',1,NULL),(23,'2026-10-24 20:47:04','2026-10-24 20:47:04',3,'Telur Ecer perbutir','TL-002','pcs',1700.00,2500.00,300.000,50.000,'products/01M5RJPHP4P7V0RFH3E21KS52C.jpg',1,NULL),(24,'2026-10-24 20:48:41','2026-10-24 20:48:41',3,'Telor Ayam Kampung ','TL-003','pcs',2500.00,3000.00,200.000,20.000,'products/01M5RJSGGHW7AY4E2P5XK6EYRR.jpg',1,NULL),(25,'2026-10-24 20:50:54','2026-10-25 14:08:33',3,'Telur Bebek','TL-004','pcs',2500.00,3000.00,199.000,20.000,'products/01M5RJXK5JNNTW4N6D1J3230B0.jpg',1,NULL),(26,'2026-10-24 20:52:49','2026-10-24 20:52:49',5,'Bright Gas 5,5kg','GS-002','tabung',90000.00,105000.00,90.000,5.000,'products/01M5RK137QTSBTW537BCS7F9KA.webp',1,NULL);
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `before_products_update` BEFORE UPDATE ON `products` FOR EACH ROW BEGIN
        IF NEW.stock < 0 THEN
            SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Stok tidak mencukupi / tidak boleh minus!';
        END IF;
    END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `after_products_update_stok` AFTER UPDATE ON `products` FOR EACH ROW BEGIN
        IF NEW.stock <> OLD.stock THEN
            INSERT INTO stock_logs
                (product_id, user_id, transaction_id, type, quantity_change, stock_before, stock_after, reference, note, created_at, updated_at)
            VALUES
                (
                    NEW.id,
                    @silaturizky_user_id,
                    @silaturizky_transaction_id,
                    COALESCE(
                        @silaturizky_stock_type,
                        IF(NEW.stock > OLD.stock, 'incoming', 'outgoing')
                    ),
                    NEW.stock - OLD.stock,
                    OLD.stock,
                    NEW.stock,
                    CONCAT('stock-update:', NEW.id, ':', UUID()),
                    IF(NEW.stock > OLD.stock, 'Stok masuk', 'Stok keluar'),
                    NOW(),
                    NOW()
                );
        END IF;
    END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES ('23BRhM8V8vkERl1kuDQkf5EyZj0dhYmx87XXk80O',5,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.143.1 Chrome/150.0.7871.250 Electron/43.7.7 Safari/537.36','YTo1OntzOjY6Il90b2tlbiI7czo0MDoia2g0dDE3Nm1kRlhLSXVwTTJuNVo2MG9IcFpRSDhEQ0FoZWwzSEgybiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6Mjc6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC9rYXNpciI7czo1OiJyb3V0ZSI7czo5OiJwb3MuaW5kZXgiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjUwOiJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI7aTo1O3M6MTc6InBhc3N3b3JkX2hhc2hfd2ViIjtzOjY0OiIyZWJlZTM5NzM4MGNhOTM5NDk5ZGU1M2U1ZTY0MmVhNGM1MjRjODExZTY5OThkN2Y5NzRhM2M0NjNlNGFlZGY4Ijt9',1792999840),('Uk2N7W3RNhouSYO1IaJkJI3ZvvACej4NPfUDR23z',NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.143.1 Chrome/150.0.7871.250 Electron/43.7.7 Safari/537.36','YTo0OntzOjY6Il90b2tlbiI7czo0MDoidlJIZnlSS3hva0hDTzJzSnhJc0Y5dnVqOWE4a2c2TmJwaGJxYmljMSI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6Mjc6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC9tYXN1ayI7czo1OiJyb3V0ZSI7czoxNDoiZW1wbG95ZWUubG9naW4iO31zOjM6InVybCI7YToxOntzOjg6ImludGVuZGVkIjtzOjI3OiJodHRwOi8vMTI3LjAuMC4xOjgwMDAvYWRtaW4iO319',1792986620);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock_logs`
--

DROP TABLE IF EXISTS `stock_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stock_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `product_id` bigint unsigned DEFAULT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `transaction_id` bigint unsigned DEFAULT NULL,
  `type` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity_change` decimal(12,3) NOT NULL,
  `stock_before` decimal(12,3) NOT NULL,
  `stock_after` decimal(12,3) NOT NULL,
  `reference` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `note` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `stock_logs_reference_unique` (`reference`),
  KEY `stock_logs_product_id_foreign` (`product_id`),
  KEY `stock_logs_user_id_foreign` (`user_id`),
  KEY `stock_logs_transaction_id_foreign` (`transaction_id`),
  CONSTRAINT `stock_logs_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE SET NULL,
  CONSTRAINT `stock_logs_transaction_id_foreign` FOREIGN KEY (`transaction_id`) REFERENCES `transactions` (`id`) ON DELETE SET NULL,
  CONSTRAINT `stock_logs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock_logs`
--

LOCK TABLES `stock_logs` WRITE;
/*!40000 ALTER TABLE `stock_logs` DISABLE KEYS */;
INSERT INTO `stock_logs` VALUES (1,1,NULL,NULL,'initial',38.000,0.000,38.000,'initial:BR-005','Stok awal saat setup toko','2026-10-17 23:06:40','2026-10-17 23:06:40'),(2,2,NULL,NULL,'initial',42.000,0.000,42.000,'initial:MG-001','Stok awal saat setup toko','2026-10-17 23:06:41','2026-10-17 23:06:41'),(3,3,NULL,NULL,'initial',27.000,0.000,27.000,'initial:TL-001','Stok awal saat setup toko','2026-10-17 23:06:41','2026-10-17 23:06:41'),(4,4,NULL,NULL,'initial',36.000,0.000,36.000,'initial:GL-001','Stok awal saat setup toko','2026-10-17 23:06:41','2026-10-17 23:06:41'),(5,5,NULL,NULL,'initial',16.000,0.000,16.000,'initial:GS-003','Stok awal saat setup toko','2026-10-17 23:06:41','2026-10-17 23:06:41'),(7,4,NULL,2,'sale',-1.000,36.000,35.000,'detail:2','Penjualan TRX-261018091028-2TQYIL','2026-10-18 09:10:29','2026-10-18 09:10:29'),(8,5,NULL,2,'sale',-1.000,16.000,15.000,'detail:3','Penjualan TRX-261018091028-2TQYIL','2026-10-18 09:10:29','2026-10-18 09:10:29'),(9,1,NULL,3,'sale',-1.000,38.000,37.000,'detail:4','Penjualan TRX-261018094716-AJB6FP','2026-10-18 09:47:16','2026-10-18 02:59:40'),(10,3,NULL,3,'sale',-1.000,27.000,26.000,'detail:5','Penjualan TRX-261018094716-AJB6FP','2026-10-18 09:47:16','2026-10-18 02:59:40'),(11,4,NULL,3,'sale',-1.000,35.000,34.000,'detail:6','Penjualan TRX-261018094716-AJB6FP','2026-10-18 09:47:16','2026-10-18 02:59:40'),(12,5,4,4,'sale',-1.000,15.000,14.000,'detail:7','Penjualan TRX-261018095019-QZQPWE','2026-10-18 09:50:19','2026-10-18 02:57:35'),(13,1,4,5,'sale',-1.000,37.000,36.000,'detail:8','Penjualan TRX-261018095917-TDFAUA','2026-10-18 09:59:17','2026-10-18 18:58:25'),(14,4,4,5,'sale',-1.000,34.000,33.000,'detail:9','Penjualan TRX-261018095917-TDFAUA','2026-10-18 09:59:17','2026-10-18 18:58:25'),(15,5,4,5,'sale',-1.000,14.000,13.000,'detail:10','Penjualan TRX-261018095917-TDFAUA','2026-10-18 09:59:17','2026-10-18 18:58:25'),(20,5,5,NULL,'incoming',25.000,13.000,38.000,'stock-update:5:37e54a3c-cb5e-11f1-8291-0492cf5a5497','tabung','2026-10-19 01:41:35','2026-10-18 18:41:35'),(21,5,5,NULL,'incoming',22.000,38.000,60.000,'stock-update:5:4aee1328-cb5e-11f1-8291-0492cf5a5497','tabung','2026-10-19 01:42:06','2026-10-18 18:42:06'),(22,3,5,7,'sale',-1.000,26.000,25.000,'stock-update:3:dd736c58-cb70-11f1-8291-0492cf5a5497','Stok keluar','2026-10-19 03:55:03','2026-10-19 03:55:03'),(23,4,5,7,'sale',-2.000,33.000,31.000,'stock-update:4:dd7552a9-cb70-11f1-8291-0492cf5a5497','Stok keluar','2026-10-19 03:55:03','2026-10-19 03:55:03'),(24,1,5,8,'sale',-1.000,36.000,35.000,'stock-update:1:f6fa1294-cb7d-11f1-8291-0492cf5a5497','Stok keluar','2026-10-19 05:28:50','2026-10-19 05:28:50'),(25,2,5,8,'sale',-1.000,42.000,41.000,'stock-update:2:f6fac996-cb7d-11f1-8291-0492cf5a5497','Stok keluar','2026-10-19 05:28:50','2026-10-19 05:28:50'),(26,1,5,NULL,'incoming',30.000,35.000,65.000,'stock-update:1:4b408cf5-d00b-11f1-8cc3-d05021b527a3','beras','2026-10-25 00:30:35','2026-10-24 17:30:35'),(27,2,5,9,'sale',-1.000,41.000,40.000,'stock-update:2:2d94454c-d00c-11f1-8cc3-d05021b527a3','Stok keluar','2026-10-25 00:36:54','2026-10-25 00:36:54'),(28,4,5,9,'sale',-1.000,31.000,30.000,'stock-update:4:2d94cfa3-d00c-11f1-8cc3-d05021b527a3','Stok keluar','2026-10-25 00:36:54','2026-10-25 00:36:54'),(29,4,5,10,'sale',-1.000,30.000,29.000,'stock-update:4:3d8c9e38-d00c-11f1-8cc3-d05021b527a3','Stok keluar','2026-10-25 00:37:21','2026-10-25 00:37:21'),(30,5,5,10,'sale',-1.000,60.000,59.000,'stock-update:5:3d8d7f63-d00c-11f1-8cc3-d05021b527a3','Stok keluar','2026-10-25 00:37:21','2026-10-25 00:37:21'),(31,1,5,11,'sale',-1.000,65.000,64.000,'stock-update:1:48a96e34-d00c-11f1-8cc3-d05021b527a3','Stok keluar','2026-10-25 00:37:40','2026-10-25 00:37:40'),(32,1,NULL,12,'sale',-1.000,64.000,63.000,'stock-update:1:686cadd0-d00d-11f1-8cc3-d05021b527a3','Stok keluar','2026-10-25 00:45:43','2026-10-25 00:45:43'),(33,4,NULL,12,'sale',-1.000,29.000,28.000,'stock-update:4:686d6344-d00d-11f1-8cc3-d05021b527a3','Stok keluar','2026-10-25 00:45:43','2026-10-25 00:45:43'),(34,1,5,NULL,'incoming',12.000,63.000,75.000,'stock-update:1:93e6688c-d01d-11f1-8cc3-d05021b527a3','beras','2026-10-25 02:41:27','2026-10-24 19:41:27'),(35,7,5,NULL,'initial',20.000,0.000,20.000,'initial:7:e3ef4395-3540-45e2-aed7-3d73a5b403a9','Stok awal saat produk dibuat','2026-10-24 19:45:06','2026-10-24 19:45:06'),(36,8,5,NULL,'initial',30.000,0.000,30.000,'initial:8:661ebe05-d6c9-41ca-a51f-d9fb902a448f','Stok awal saat produk dibuat','2026-10-24 19:49:32','2026-10-24 19:49:32'),(37,9,5,NULL,'initial',20.000,0.000,20.000,'initial:9:f13016b9-0896-493a-b0ed-24c388bd9204','Stok awal saat produk dibuat','2026-10-24 19:51:43','2026-10-24 19:51:43'),(38,10,5,NULL,'initial',80.000,0.000,80.000,'initial:10:72c1b21c-c5a9-41f2-afc0-336eb1c32e9d','Stok awal saat produk dibuat','2026-10-24 20:02:28','2026-10-24 20:02:28'),(39,11,5,NULL,'initial',80.000,0.000,80.000,'initial:11:2e6ec657-bfbf-450b-bfa6-d633e8456a30','Stok awal saat produk dibuat','2026-10-24 20:12:25','2026-10-24 20:12:25'),(40,12,5,NULL,'initial',80.000,0.000,80.000,'initial:12:0e0058f1-ee64-4842-b308-58e2d10101a5','Stok awal saat produk dibuat','2026-10-24 20:14:16','2026-10-24 20:14:16'),(41,13,5,NULL,'initial',80.000,0.000,80.000,'initial:13:3578c028-94fa-4a25-88a9-a4fd9cd02c6d','Stok awal saat produk dibuat','2026-10-24 20:17:41','2026-10-24 20:17:41'),(42,14,5,NULL,'initial',80.000,0.000,80.000,'initial:14:5efff0dc-513b-44e0-9aab-63242c639122','Stok awal saat produk dibuat','2026-10-24 20:21:06','2026-10-24 20:21:06'),(43,15,5,NULL,'initial',80.000,0.000,80.000,'initial:15:1c4a7504-c965-4f9a-ab8d-7058b2d31219','Stok awal saat produk dibuat','2026-10-24 20:23:18','2026-10-24 20:23:18'),(44,16,5,NULL,'initial',100.000,0.000,100.000,'initial:16:a6fc561b-ccad-4658-a04c-fba88fe2be0a','Stok awal saat produk dibuat','2026-10-24 20:26:10','2026-10-24 20:26:10'),(45,17,5,NULL,'initial',100.000,0.000,100.000,'initial:17:ea49cc27-71ce-4b41-9acd-31c9f282ca5f','Stok awal saat produk dibuat','2026-10-24 20:31:13','2026-10-24 20:31:13'),(46,18,5,NULL,'initial',100.000,0.000,100.000,'initial:18:93f05709-4b06-4991-886c-5052b5382e1e','Stok awal saat produk dibuat','2026-10-24 20:34:20','2026-10-24 20:34:20'),(47,19,5,NULL,'initial',100.000,0.000,100.000,'initial:19:89492de7-3573-48a8-856f-6bdc5e403548','Stok awal saat produk dibuat','2026-10-24 20:35:47','2026-10-24 20:35:47'),(48,20,5,NULL,'initial',100.000,0.000,100.000,'initial:20:c9b71eca-e903-427d-b9c0-ee4ee992db33','Stok awal saat produk dibuat','2026-10-24 20:37:32','2026-10-24 20:37:32'),(49,21,5,NULL,'initial',90.000,0.000,90.000,'initial:21:c90bea8c-a46c-4655-b802-2155d398dfdc','Stok awal saat produk dibuat','2026-10-24 20:43:18','2026-10-24 20:43:18'),(50,22,5,NULL,'initial',100.000,0.000,100.000,'initial:22:bf9f52c7-2be4-47d6-b718-2a82911e3860','Stok awal saat produk dibuat','2026-10-24 20:44:58','2026-10-24 20:44:58'),(51,23,5,NULL,'initial',300.000,0.000,300.000,'initial:23:cea15eb9-2ae2-49a2-b865-3f7a8d22c6de','Stok awal saat produk dibuat','2026-10-24 20:47:04','2026-10-24 20:47:04'),(52,24,5,NULL,'initial',200.000,0.000,200.000,'initial:24:12d36f6b-906b-4829-9ec1-130ec2d99908','Stok awal saat produk dibuat','2026-10-24 20:48:41','2026-10-24 20:48:41'),(53,25,5,NULL,'initial',200.000,0.000,200.000,'initial:25:87e79dd6-0d71-4393-9f71-fc9381d69305','Stok awal saat produk dibuat','2026-10-24 20:50:54','2026-10-24 20:50:54'),(54,26,5,NULL,'initial',90.000,0.000,90.000,'initial:26:c6c60a0c-793f-4252-892d-60930960df9f','Stok awal saat produk dibuat','2026-10-24 20:52:49','2026-10-24 20:52:49'),(55,4,5,13,'sale',-2.000,28.000,26.000,'stock-update:4:d2750401-d02c-11f1-8cc3-d05021b527a3','Stok keluar','2026-10-25 04:30:35','2026-10-25 04:30:35'),(56,9,5,13,'sale',-1.000,20.000,19.000,'stock-update:9:d2763bd7-d02c-11f1-8cc3-d05021b527a3','Stok keluar','2026-10-25 04:30:35','2026-10-25 04:30:35'),(57,13,5,14,'sale',-1.000,80.000,79.000,'stock-update:13:ed982932-d02c-11f1-8cc3-d05021b527a3','Stok keluar','2026-10-25 04:31:20','2026-10-25 04:31:20'),(58,15,5,14,'sale',-1.000,80.000,79.000,'stock-update:15:ed9a04fe-d02c-11f1-8cc3-d05021b527a3','Stok keluar','2026-10-25 04:31:20','2026-10-25 04:31:20'),(59,9,5,15,'sale',-3.000,19.000,16.000,'stock-update:9:f3e50e4d-d07b-11f1-8cc3-d05021b527a3','Stok keluar','2026-10-25 13:57:01','2026-10-25 13:57:01'),(60,16,5,16,'sale',-1.000,100.000,99.000,'stock-update:16:c92057d8-d07c-11f1-8cc3-d05021b527a3','Stok keluar','2026-10-25 14:02:59','2026-10-25 14:02:59'),(61,22,5,16,'sale',-1.000,100.000,99.000,'stock-update:22:c921499a-d07c-11f1-8cc3-d05021b527a3','Stok keluar','2026-10-25 14:02:59','2026-10-25 14:02:59'),(62,25,7,17,'sale',-1.000,200.000,199.000,'stock-update:25:903ef185-d07d-11f1-8cc3-d05021b527a3','Stok keluar','2026-10-25 14:08:33','2026-10-25 14:08:33');
/*!40000 ALTER TABLE `stock_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transaction_details`
--

DROP TABLE IF EXISTS `transaction_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transaction_details` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `transaction_id` bigint unsigned NOT NULL,
  `product_id` bigint unsigned DEFAULT NULL,
  `product_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `unit` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` decimal(12,3) NOT NULL,
  `unit_price` decimal(15,2) NOT NULL,
  `purchase_price` decimal(15,2) NOT NULL DEFAULT '0.00',
  `subtotal` decimal(15,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `transaction_details_transaction_id_foreign` (`transaction_id`),
  KEY `transaction_details_product_id_foreign` (`product_id`),
  CONSTRAINT `transaction_details_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE SET NULL,
  CONSTRAINT `transaction_details_transaction_id_foreign` FOREIGN KEY (`transaction_id`) REFERENCES `transactions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transaction_details`
--

LOCK TABLES `transaction_details` WRITE;
/*!40000 ALTER TABLE `transaction_details` DISABLE KEYS */;
INSERT INTO `transaction_details` VALUES (2,'2026-10-18 02:10:28','2026-10-18 02:10:28',2,4,'Gula Pasir 1kg','pcs',1.000,18000.00,0.00,18000.00),(3,'2026-10-18 02:10:29','2026-10-18 02:10:29',2,5,'Gas LPG 3kg','tabung',1.000,22000.00,0.00,22000.00),(4,'2026-10-18 02:47:16','2026-10-18 02:47:16',3,1,'Beras Premium 5kg','pcs',1.000,82000.00,0.00,82000.00),(5,'2026-10-18 02:47:16','2026-10-18 02:47:16',3,3,'Telor Ayam 1kg','kg',1.000,30000.00,0.00,30000.00),(6,'2026-10-18 02:47:16','2026-10-18 02:47:16',3,4,'Gula Pasir 1kg','pcs',1.000,18000.00,0.00,18000.00),(7,'2026-10-18 02:50:19','2026-10-18 02:50:19',4,5,'Gas LPG 3kg','tabung',1.000,22000.00,0.00,22000.00),(8,'2026-10-18 02:59:17','2026-10-18 02:59:17',5,1,'Beras Premium 5kg','pcs',1.000,82000.00,0.00,82000.00),(9,'2026-10-18 02:59:17','2026-10-18 02:59:17',5,4,'Gula Pasir 1kg','pcs',1.000,18000.00,0.00,18000.00),(10,'2026-10-18 02:59:17','2026-10-18 02:59:17',5,5,'Gas LPG 3kg','tabung',1.000,22000.00,0.00,22000.00),(12,'2026-10-18 20:55:03','2026-10-18 20:55:03',7,3,'Telor Ayam 1kg','kg',1.000,30000.00,26000.00,30000.00),(13,'2026-10-18 20:55:03','2026-10-18 20:55:03',7,4,'Gula Pasir 1kg','pcs',2.000,18000.00,15500.00,36000.00),(14,'2026-10-18 22:28:49','2026-10-18 22:28:49',8,1,'Beras Premium 5kg','pcs',1.000,82000.00,72000.00,82000.00),(15,'2026-10-18 22:28:50','2026-10-18 22:28:50',8,2,'MinyakKita 1L','pcs',1.000,18000.00,15500.00,18000.00),(16,'2026-10-24 17:36:54','2026-10-24 17:36:54',9,2,'MinyakKita 1L','pcs',1.000,18000.00,15500.00,18000.00),(17,'2026-10-24 17:36:54','2026-10-24 17:36:54',9,4,'Gula Pasir 1kg','pcs',1.000,18000.00,15500.00,18000.00),(18,'2026-10-24 17:37:21','2026-10-24 17:37:21',10,4,'Gula Pasir 1kg','pcs',1.000,18000.00,15500.00,18000.00),(19,'2026-10-24 17:37:21','2026-10-24 17:37:21',10,5,'Gas LPG 3kg','tabung',1.000,22000.00,19000.00,22000.00),(20,'2026-10-24 17:37:40','2026-10-24 17:37:40',11,1,'Beras Premium 5kg','pcs',1.000,82000.00,72000.00,82000.00),(21,'2026-10-24 17:45:43','2026-10-24 17:45:43',12,1,'Beras Premium 5kg','pcs',1.000,82000.00,72000.00,82000.00),(22,'2026-10-24 17:45:43','2026-10-24 17:45:43',12,4,'Gula Pasir 1kg','pcs',1.000,18000.00,15500.00,18000.00),(23,'2026-10-24 21:30:35','2026-10-24 21:30:35',13,4,'Gula Pasir Putih curah','kg',2.000,16000.00,14500.00,32000.00),(24,'2026-10-24 21:30:35','2026-10-24 21:30:35',13,9,'Beras Ketan Putih','kg',1.000,20000.00,18000.00,20000.00),(25,'2026-10-24 21:31:20','2026-10-24 21:31:20',14,13,'Indomie Goreng Jumbo ','pcs',1.000,5000.00,3000.00,5000.00),(26,'2026-10-24 21:31:20','2026-10-24 21:31:20',14,15,'Indomie Goreng Cabe Ijo','pcs',1.000,4000.00,3200.00,4000.00),(27,'2026-10-25 06:57:01','2026-10-25 06:57:01',15,9,'Beras Ketan Putih','kg',3.000,20000.00,18000.00,60000.00),(28,'2026-10-25 14:02:59','2026-10-25 14:02:59',16,16,'Gulaku Kuning 1kg','kg',1.000,19000.00,17000.00,19000.00),(29,'2026-10-25 14:02:59','2026-10-25 14:02:59',16,22,'Aci Curah 1kg','kg',1.000,11000.00,9000.00,11000.00),(30,'2026-10-25 14:08:33','2026-10-25 14:08:33',17,25,'Telur Bebek','pcs',1.000,3000.00,2500.00,3000.00);
/*!40000 ALTER TABLE `transaction_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transactions`
--

DROP TABLE IF EXISTS `transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transactions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `handled_by` bigint unsigned DEFAULT NULL,
  `transaction_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subtotal` decimal(15,2) NOT NULL DEFAULT '0.00',
  `total` decimal(15,2) NOT NULL DEFAULT '0.00',
  `total_cost` decimal(15,2) NOT NULL DEFAULT '0.00',
  `amount_paid` decimal(15,2) NOT NULL DEFAULT '0.00',
  `change_amount` decimal(15,2) NOT NULL DEFAULT '0.00',
  `payment_method` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'cash',
  `payment_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `status` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'completed',
  `completed_at` timestamp NULL DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `customer_name` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer_phone` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_address` text COLLATE utf8mb4_unicode_ci,
  `pickup_note` text COLLATE utf8mb4_unicode_ci,
  `sales_channel` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pos',
  `delivery_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pickup',
  PRIMARY KEY (`id`),
  UNIQUE KEY `transactions_transaction_number_unique` (`transaction_number`),
  KEY `transactions_user_id_foreign` (`user_id`),
  KEY `transactions_handled_by_foreign` (`handled_by`),
  CONSTRAINT `transactions_handled_by_foreign` FOREIGN KEY (`handled_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `transactions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transactions`
--

LOCK TABLES `transactions` WRITE;
/*!40000 ALTER TABLE `transactions` DISABLE KEYS */;
INSERT INTO `transactions` VALUES (2,'2026-10-18 02:10:28','2026-10-18 02:10:28',NULL,NULL,'TRX-261018091028-2TQYIL',40000.00,40000.00,34500.00,100000.00,60000.00,'cash','paid','completed','2026-10-18 02:10:28',NULL,NULL,NULL,NULL,NULL,'pos','pickup'),(3,'2026-10-18 02:47:16','2026-10-18 02:59:40',NULL,NULL,'TRX-261018094716-AJB6FP',130000.00,130000.00,113500.00,130000.00,0.00,'cash_on_pickup','paid','completed','2026-10-18 02:59:40',NULL,'fihan','085871525227',NULL,'diambil pukul 20.00','storefront','pickup'),(4,'2026-10-18 02:50:19','2026-10-18 02:57:35',4,NULL,'TRX-261018095019-QZQPWE',22000.00,22000.00,19000.00,22000.00,0.00,'cash_on_pickup','paid','completed','2026-10-18 02:57:35',NULL,'fihan shecilia','085871425227','Blk.Odading','20.00','storefront','pickup'),(5,'2026-10-18 02:59:17','2026-10-18 18:58:25',4,5,'TRX-261018095917-TDFAUA',122000.00,122000.00,106500.00,122000.00,0.00,'cash_on_pickup','paid','completed','2026-10-18 18:58:25',NULL,'fihan shecilia','085871425227','Blk.Odading','17.00','storefront','pickup'),(7,'2026-10-18 20:55:03','2026-10-18 20:55:03',5,5,'TRX-261019035503-GP31O7',66000.00,66000.00,57000.00,100000.00,34000.00,'cash','paid','completed','2026-10-18 20:55:03',NULL,NULL,NULL,NULL,NULL,'pos','pickup'),(8,'2026-10-18 22:28:49','2026-10-18 22:28:49',5,5,'TRX-261019052849-JOQ3DS',100000.00,100000.00,87500.00,100000.00,0.00,'cash','paid','completed','2026-10-18 22:28:49',NULL,NULL,NULL,NULL,NULL,'pos','pickup'),(9,'2026-10-24 17:36:54','2026-10-24 17:36:54',5,5,'TRX-261025003654-PYCJTP',36000.00,36000.00,31000.00,36000.00,0.00,'qris','paid','completed','2026-10-24 17:36:54',NULL,NULL,NULL,NULL,NULL,'pos','pickup'),(10,'2026-10-24 17:37:21','2026-10-24 17:37:21',5,5,'TRX-261025003721-ZZASJN',40000.00,40000.00,34500.00,100000.00,60000.00,'cash','paid','completed','2026-10-24 17:37:21',NULL,NULL,NULL,NULL,NULL,'pos','pickup'),(11,'2026-10-24 17:37:40','2026-10-24 17:37:40',5,5,'TRX-261025003740-0CCOSG',82000.00,82000.00,72000.00,100000.00,18000.00,'cash','paid','completed','2026-10-24 17:37:40',NULL,NULL,NULL,NULL,NULL,'pos','pickup'),(12,'2026-10-24 17:45:43','2026-10-24 17:45:43',NULL,NULL,'TRX-261025004543-VJHLKW',100000.00,100000.00,87500.00,100000.00,0.00,'cash','paid','completed','2026-10-24 17:45:43',NULL,NULL,NULL,NULL,NULL,'pos','pickup'),(13,'2026-10-24 21:30:35','2026-10-24 21:30:35',5,5,'TRX-261025043035-KAFXJA',52000.00,52000.00,47000.00,100000.00,48000.00,'cash','paid','completed','2026-10-24 21:30:35',NULL,NULL,NULL,NULL,NULL,'pos','pickup'),(14,'2026-10-24 21:31:20','2026-10-24 21:31:20',5,5,'TRX-261025043120-V8QTLY',9000.00,9000.00,6200.00,9000.00,0.00,'qris','paid','completed','2026-10-24 21:31:20',NULL,NULL,NULL,NULL,NULL,'pos','pickup'),(15,'2026-10-25 06:57:01','2026-10-25 06:57:01',5,5,'TRX-261025135701-MKGE7O',60000.00,60000.00,54000.00,100000.00,40000.00,'cash','paid','completed','2026-10-25 06:57:01',NULL,NULL,NULL,NULL,NULL,'pos','pickup'),(16,'2026-10-25 14:02:59','2026-10-25 14:02:59',5,5,'TRX-261025210259-MU962Y',30000.00,30000.00,26000.00,30000.00,0.00,'qris','paid','completed','2026-10-25 14:02:59',NULL,NULL,NULL,NULL,NULL,'pos','pickup'),(17,'2026-10-25 14:08:33','2026-10-25 14:08:33',7,7,'TRX-261025210833-M8XSZN',3000.00,3000.00,2500.00,3000.00,0.00,'qris','paid','completed','2026-10-25 14:08:33',NULL,NULL,NULL,NULL,NULL,'pos','pickup');
/*!40000 ALTER TABLE `transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `role` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pembeli',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `wa_number` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alamat` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  UNIQUE KEY `users_phone_unique` (`phone`),
  UNIQUE KEY `users_wa_number_unique` (`wa_number`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (3,'Pelanggan Contoh','pembeli@gmail.com','081234567891',NULL,'$2y$12$MoQ2JKVc5WdZOeZ1GTWZXe/bs3rBj1K9MVelu5/SFVUjv5/O9iLbS',NULL,'2026-10-17 23:06:40','2026-10-18 01:27:43','pembeli',1,'081234567891',NULL),(4,'fihan shecilia','fihanshecilia10@gmail.com','085871425227',NULL,'$2y$12$3EsBNyUJHjJskFH5ibbw6OHZhot6CStnalIU56Ptv3bXB.MwpIWtS',NULL,'2026-10-18 02:14:15','2026-10-18 02:14:15','pembeli',1,'085871425227','Blk.Odading'),(5,'Admin Toko Silaturizky','tokosilaturizky@gmail.com',NULL,NULL,'$2y$12$.OQWcHNJWiM8Ek8329sGb.dPBpo.mvB4ziSzb3Jw2WL5W0i1SSKwu',NULL,'2026-10-18 18:17:17','2026-10-18 18:17:17','admin_toko',1,NULL,NULL),(7,'Kasir uji','kasir.uji@tokosilaturizky.local',NULL,NULL,'$2y$12$bqXvIFXT1oUMnStwj05kxuw7aYtpDVhxD5Cxf9gOiHM2lAjAmtcDC',NULL,'2026-10-25 06:56:08','2026-10-25 06:56:08','kasir',1,NULL,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `view_laporan_penjualan_harian`
--

DROP TABLE IF EXISTS `view_laporan_penjualan_harian`;
/*!50001 DROP VIEW IF EXISTS `view_laporan_penjualan_harian`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `view_laporan_penjualan_harian` AS SELECT 
 1 AS `tanggal`,
 1 AS `total_transaksi`,
 1 AS `omzet`,
 1 AS `laba_kotor`*/;
SET character_set_client = @saved_cs_client;

--
-- Dumping routines for database 'toko_silaturizky'
--
/*!50003 DROP FUNCTION IF EXISTS `hitung_laba` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `hitung_laba`(p_jual DECIMAL(15,2), p_modal DECIMAL(15,2)) RETURNS decimal(15,2)
    DETERMINISTIC
RETURN p_jual - p_modal ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `hitung_omzet_periode` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `hitung_omzet_periode`(p_tgl_mulai DATE, p_tgl_selesai DATE) RETURNS decimal(15,2)
    READS SQL DATA
RETURN (
        SELECT COALESCE(SUM(total), 0)
        FROM transactions
        WHERE status = 'completed'
          AND DATE(created_at) BETWEEN p_tgl_mulai AND p_tgl_selesai
    ) ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `laporan_harian` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `laporan_harian`()
BEGIN
        SELECT
            COALESCE((
                SELECT SUM(total)
                FROM transactions
                WHERE status = 'completed' AND DATE(created_at) = CURRENT_DATE()
            ), 0) AS omzet,
            COALESCE((
                SELECT SUM(hitung_laba(d.subtotal, d.purchase_price * d.quantity))
                FROM transaction_details d
                JOIN transactions t ON t.id = d.transaction_id
                WHERE t.status = 'completed' AND DATE(t.created_at) = CURRENT_DATE()
            ), 0) AS laba_bersih,
            (
                SELECT COUNT(*)
                FROM transactions
                WHERE status = 'completed' AND DATE(created_at) = CURRENT_DATE()
            ) AS total_transaksi;
    END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proses_checkout` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proses_checkout`(IN p_transaction_id BIGINT UNSIGNED)
BEGIN
        DECLARE v_status VARCHAR(50);
        DECLARE v_item_count INT DEFAULT 0;
        DECLARE v_insufficient_count INT DEFAULT 0;
        DECLARE EXIT HANDLER FOR SQLEXCEPTION
        BEGIN
            ROLLBACK;
            RESIGNAL;
        END;

        START TRANSACTION;

        SELECT status INTO v_status
        FROM transactions
        WHERE id = p_transaction_id
        FOR UPDATE;

        IF v_status IS NULL THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Transaksi tidak ditemukan.';
        END IF;

        IF v_status = 'completed' THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Transaksi sudah berstatus selesai.';
        END IF;

        SELECT COUNT(*) INTO v_item_count
        FROM transaction_details
        WHERE transaction_id = p_transaction_id;

        IF v_item_count = 0 THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Detail item transaksi kosong.';
        END IF;

        SELECT COUNT(*) INTO v_insufficient_count
        FROM transaction_details td
        JOIN products p ON p.id = td.product_id
        WHERE td.transaction_id = p_transaction_id AND p.stock < td.quantity;

        IF v_insufficient_count > 0 THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Stok tidak mencukupi / tidak boleh minus!';
        END IF;

        UPDATE products p
        JOIN transaction_details td ON td.product_id = p.id
        SET p.stock = p.stock - td.quantity
        WHERE td.transaction_id = p_transaction_id;

        UPDATE transactions
        SET status = 'completed',
            payment_status = 'paid',
            completed_at = COALESCE(completed_at, NOW()),
            updated_at = NOW()
        WHERE id = p_transaction_id;

        COMMIT;
    END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Final view structure for view `order_items`
--

/*!50001 DROP VIEW IF EXISTS `order_items`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `order_items` AS select `transaction_details`.`id` AS `id`,`transaction_details`.`created_at` AS `created_at`,`transaction_details`.`updated_at` AS `updated_at`,`transaction_details`.`transaction_id` AS `transaction_id`,`transaction_details`.`product_id` AS `product_id`,`transaction_details`.`product_name` AS `product_name`,`transaction_details`.`unit` AS `unit`,`transaction_details`.`quantity` AS `quantity`,`transaction_details`.`unit_price` AS `unit_price`,`transaction_details`.`purchase_price` AS `purchase_price`,`transaction_details`.`subtotal` AS `subtotal` from `transaction_details` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `orders`
--

/*!50001 DROP VIEW IF EXISTS `orders`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `orders` AS select `transactions`.`id` AS `id`,`transactions`.`created_at` AS `created_at`,`transactions`.`updated_at` AS `updated_at`,`transactions`.`user_id` AS `user_id`,`transactions`.`handled_by` AS `handled_by`,`transactions`.`transaction_number` AS `transaction_number`,`transactions`.`subtotal` AS `subtotal`,`transactions`.`total` AS `total`,`transactions`.`total_cost` AS `total_cost`,`transactions`.`amount_paid` AS `amount_paid`,`transactions`.`change_amount` AS `change_amount`,`transactions`.`payment_method` AS `payment_method`,`transactions`.`payment_status` AS `payment_status`,`transactions`.`status` AS `status`,`transactions`.`completed_at` AS `completed_at`,`transactions`.`notes` AS `notes`,`transactions`.`customer_name` AS `customer_name`,`transactions`.`customer_phone` AS `customer_phone`,`transactions`.`shipping_address` AS `shipping_address`,`transactions`.`pickup_note` AS `pickup_note`,`transactions`.`sales_channel` AS `sales_channel`,`transactions`.`delivery_type` AS `delivery_type` from `transactions` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_laporan_penjualan_harian`
--

/*!50001 DROP VIEW IF EXISTS `view_laporan_penjualan_harian`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_laporan_penjualan_harian` AS select cast(`transactions`.`created_at` as date) AS `tanggal`,count(`transactions`.`id`) AS `total_transaksi`,coalesce(sum(`transactions`.`total`),0) AS `omzet`,coalesce(sum((`transactions`.`total` - `transactions`.`total_cost`)),0) AS `laba_kotor` from `transactions` where (`transactions`.`status` = 'completed') group by cast(`transactions`.`created_at` as date) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-10-26 20:15:28
